# Support Discord Server: https://discord.gg/aeDraxAUpB

# Fishing Frenzy

All these cheats in the folder can be used in Fishing Frenzy.

# addWeight.js

### Get the script from the file [addWeight.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/Fishing-Frenzy/addWeight.js)

# setFrenzy.js

### Get the script from the file [setFrenzy.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/Fishing-Frenzy/setFrenzy.js)

# setLure.js

### Get the script from the file [setLure.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/Fishing-Frenzy/setLure.js)
