---
name: Suggestion
about: If you have an idea for a hack or something you can use this to suggest it.
title: 'IDEA: Idea'
labels: "[IMPROVEMENT]"
assignees: monkxy

---

## Describe your idea for a hack/improvement.
