<div align="center">
    
<h3 align="center">Blooket Hacks</h3>
<h4 align="center">Coded by <a href="https://github.com/monkxy/">Monkxy (Jude)</h4>

<span id="badges-container" >
    <img alt="Issues" src="https://img.shields.io/github/issues/monkxy/blooket-hacks?color=blue"/>
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/monkxy/blooket-hacks?color=blue"/>
    <img alt="License" src="https://img.shields.io/badge/license-MPL-blue"/>
    <img alt="Stars" src="https://img.shields.io/github/stars/monkxy/blooket-hacks?color=blue"/>
    <img alt="Forks" src="https://img.shields.io/github/forks/monkxy/blooket-hacks?color=blue"/>
</span>

 # Support Discord: https://discord.gg/monkxy

# Blooket Hacks

This repo contains hacks for the popular game [Blooket](https://blooket.com/)!
## Acknowledgements

 - I am NOT responsible for any actions taken on your account for using this hack.
 - Always use this with care, know there is a chance of getting banned.
 - Follow the [license](https://github.com/Jude-Gideon/Blooket/blob/main/LICENSE) when forking this repo.
## Support

For support, create an [issue](https://github.com/Jude-Gideon/Blooket/issues/new) or join our [Discord](https://discord.gg/aeDraxAUpB).

> These should always be working, let me know of any issues.

## Usage

https://user-images.githubusercontent.com/113489420/213098794-5cc5c89b-a4a2-4715-a93a-c04a52f786d6.mp4

1. Go to Blooket

2. Push CTRL + SHIFT + J

3. Paste the code.


## Authors

- [@monkxy](https://www.github.com/monkxy) (Jude)
