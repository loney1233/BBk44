# Support Discord Server: https://discord.gg/aeDraxAUpB

# Global

All these cheats in the folder can be used outside games.

# addRewards.js

Note: **This cheat also includes adding max xp for the day.**

### Get the script from the file [addRewards.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/Global/addRewards.js)

# allBlooks.js

### Get the script from the file [allBlooks.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/Global/allBlooks.js)

# answersCorrect.js

### Get the script from the file [answersCorrect.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/global/answersCorrect.js)

# antiBan.js

### Get the script from the file [antiBan.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/Global/antiBan.js)

# noDelay.js

### Get the script from the fil [noDelay.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/Global/noDelay.js)

# openPacks.js

### Get the script from the file [openPacks.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/global/openPacks.js)

# plusGamemodes.js

### Get the script from the file [plusGamemodes.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/Global/plusGamemodes.js)

# sellDuplicates.js

### Get the script from the file [sellDuplicates.js](https://raw.githubusercontent.com/Jude-Gideon/Blooket/main/global/sellDuplicates.js)
